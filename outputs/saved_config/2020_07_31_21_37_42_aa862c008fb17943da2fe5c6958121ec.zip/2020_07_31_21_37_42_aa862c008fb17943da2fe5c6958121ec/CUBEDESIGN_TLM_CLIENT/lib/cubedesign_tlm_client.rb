# This class can be used in your scripts like so:
#   require 'cubedesign_tlm_client'
#   cubedesign_tlm_client = Cubedesign_tlm_client.new
#   cubedesign_tlm_client.utility
# For more information see the COSMOS scripting guide

class Cubedesign_tlm_client
  def utility
  end
end
