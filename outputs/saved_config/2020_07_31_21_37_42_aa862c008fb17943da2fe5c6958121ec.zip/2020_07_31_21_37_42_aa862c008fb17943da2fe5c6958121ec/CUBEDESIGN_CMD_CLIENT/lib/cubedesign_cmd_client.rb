# This class can be used in your scripts like so:
#   require 'cubedesign_cmd_client'
#   cubedesign_cmd_client = Cubedesign_cmd_client.new
#   cubedesign_cmd_client.utility
# For more information see the COSMOS scripting guide

class Cubedesign_cmd_client
  def utility
  end
end
